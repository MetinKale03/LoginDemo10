package com.example.logindemo;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface Api {
    String BASE_URL = "https://archief.vhsj.be/";

    @FormUrlEncoded
    @POST("websites/6itn/gip14/api/login.php")
    Call<LoginResult> login(@Field("username") String userName,@Field("password") String passWord);

    @FormUrlEncoded
    @POST("websites/6itn/gip14/api/loon.php")
    Call<Boolean> loon(@Field("username") String userName,@Field("password") String passWord,@Field("loon") String loon);
}
