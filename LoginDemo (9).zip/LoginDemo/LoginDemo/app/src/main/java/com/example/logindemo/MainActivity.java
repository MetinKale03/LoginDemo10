package com.example.logindemo;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private EditText Name;
    private EditText Password;
    private TextView Info;
    private Button Login;
    private int counter = 5;
    private ProgressBar loadingProgressBar;

    private LoginViewModel loginViewModel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Name=(EditText) findViewById(R.id.txtName);
        Password=(EditText) findViewById(R.id.txtPassword);
        Info=(TextView) findViewById(R.id.txtFout);
        Login =(Button) findViewById(R.id.btnLogin);

        Info.setText("Aantal pogingen: 5");

        loadingProgressBar = findViewById(R.id.loading);

        loginViewModel= ViewModelProviders.of(this).get(LoginViewModel.class);
        loginViewModel.getLoginFormState().observe(this, new Observer<LoginFormState>() {
            @Override
            public void onChanged(@Nullable LoginFormState loginFormState) {
                if (loginFormState == null) {
                    return;
                }
                Login.setEnabled(loginFormState.isDataValid());
                if (loginFormState.getUsernameError() != null) {
                    Name.setError(getString(loginFormState.getUsernameError()));
                }
                if (loginFormState.getPasswordError() != null) {
                    Password.setError(getString(loginFormState.getPasswordError()));
                }
            }
        });

        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
                loginViewModel.loginDataChanged(Name.getText().toString(),
                        Password.getText().toString());
            }
        };
        Name.addTextChangedListener(afterTextChangedListener);
        Password.addTextChangedListener(afterTextChangedListener);
        Password.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    if(Login.isEnabled()){
                        validate(Name.getText().toString(),
                                Password.getText().toString());
                    }

                }
                return false;
            }
        });

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(Name.getText().toString(),Password.getText().toString());

            }
        });


    }

    private void validate(String userName, String userPassword){
        loadingProgressBar.setVisibility(View.VISIBLE);

        Call<LoginResult> call = RetrofitClient.getInstance().getMyApi().login(userName,userPassword);
        call.enqueue(new Callback<LoginResult>() {
            @Override
            public void onResponse(Call<LoginResult> call, Response<LoginResult> response) {
                loadingProgressBar.setVisibility(View.GONE);
                if(response.isSuccessful()) {

                    LoginResult myheroList = response.body();
                    Log.i("LoginDemo:",myheroList.toString());
                    Toast.makeText(getApplicationContext(), myheroList.getMessage(), Toast.LENGTH_LONG).show();
                    Intent intent=new Intent(MainActivity.this, SecondActivity.class);
                    intent.putExtra("userName",userName);
                    intent.putExtra("userPassword",userPassword);
                    intent.putExtra("loon",myheroList.getLoon());
                    startActivity(intent);
                }
                else {

                    if(response.errorBody() != null) {
                        try {
                            Toast.makeText(getApplicationContext(), response.errorBody().string(), Toast.LENGTH_LONG).show();
                            Log.i("LoginDemo:", response.errorBody().string());
                            counter--;
                            Info.setText("Aantal pogingen: "+ String.valueOf(counter));

                            if(counter==0)
                            {
                                Login.setEnabled(false);
                            }
                        } catch (IOException e) {
                            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                            e.printStackTrace();
                        }
                    }
                }

            }

            @Override
            public void onFailure(Call<LoginResult> call, Throwable t) {

                Toast.makeText(getApplicationContext(), t.toString(), Toast.LENGTH_LONG).show();
                counter--;
                Info.setText("Aantal pogingen: "+ String.valueOf(counter));

                if(counter==0)
                {
                    Login.setEnabled(false);
                }
            }

        });
        /*if((userName.equals("Admin"))&&(userPassword.equals("1234")))
        {
            Intent intent=new Intent(MainActivity.this, SecondActivity.class);
            intent.putExtra("userName",userName);
            intent.putExtra("userPassword",userPassword);
            startActivity(intent);
        }
        else{
            counter--;
            Info.setText("Aantal pogingen: "+ String.valueOf(counter));

            if(counter==0)
            {
                Login.setEnabled(false);
            }
        }*/
    }


}