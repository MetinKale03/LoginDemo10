package com.example.logindemo;

import com.google.gson.annotations.SerializedName;

public class LoginResult {
    @SerializedName("message")
    private String message;
    private Double loon;


    public LoginResult(String message,Double loon) {
        this.message = message;
        this.loon=loon;
    }


    public String getMessage() {
        return message;
    }
    public Double getLoon(){return loon; }
}
